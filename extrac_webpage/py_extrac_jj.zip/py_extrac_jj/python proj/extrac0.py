import urllib2
url = 'http://wap.jjwxc.net/book2/785921/38'
req = urllib2.Request(url)  
response = urllib2.urlopen(req).read() 
response = unicode(response,'GBK').encode('UTF-8')
print response
text_file = open("C:\Users\sandrac\Desktop\Output.txt", "w")
text_file.write("Purchase Amount: %s" % response)
text_file.close()
